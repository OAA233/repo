#import "tvdiag.h"

#include <dlfcn.h>
#include <errno.h>
#include <string.h>
#include <sys/sysctl.h>
#include <sys/utsname.h>
#include <unistd.h>

#ifndef PACKAGE_VERSION
#define PACKAGE_VERSION "unknown"
#endif
#ifndef THEOS_PACKAGE_SCHEME
#define THEOS_PACKAGE_SCHEME "legacy"
#endif

static NSString *gDiagDir = nil;
static NSString *gDiagPath = nil;
static NSLock *gDiagLock = nil;

#pragma mark - 环境采集

static NSString *diagSysctl(const char *name) {
    size_t size = 0;
    if (sysctlbyname(name, NULL, &size, NULL, 0) != 0 || size == 0)
        return nil;
    char *buf = (char *)calloc(1, size);
    if (!buf)
        return nil;
    NSString *value = nil;
    if (sysctlbyname(name, buf, &size, NULL, 0) == 0)
        value = [NSString stringWithUTF8String:buf];
    free(buf);
    return value;
}

static NSString *diagFileExists(NSString *path) {
    return [[NSFileManager defaultManager] fileExistsAtPath:path] ? @"在" : @"不在";
}

static NSString *diagSymbol(NSString *framework, const char *symbol) {
    void *handle = dlopen(framework.UTF8String, RTLD_LAZY);
    if (!handle)
        return [NSString stringWithFormat:@"%@ 打不开（%s）", framework, dlerror()];
    void *sym = dlsym(handle, symbol);
    dlclose(handle);
    return sym ? @"有" : @"没有";
}

NSString *tvDiagDirectory(void) {
    if (gDiagDir)
        return gDiagDir;
    NSFileManager *fm = [NSFileManager defaultManager];
    // 优先写「文件 App → 我的 iPhone」能看到的目录，用户才好把文件发出来
    NSArray *bases = @[@"/var/mobile/Documents", @"/var/jb/var/mobile/Documents", @"/tmp"];
    for (NSString *base in bases) {
        NSString *dir = [base stringByAppendingPathComponent:@"Mirror17"];
        if ([fm createDirectoryAtPath:dir withIntermediateDirectories:YES attributes:nil error:NULL]) {
            gDiagDir = dir;
            break;
        }
    }
    return gDiagDir;
}

NSString *tvDiagFile(void) {
    if (gDiagPath)
        return gDiagPath;
    NSString *dir = tvDiagDirectory();
    if (!dir)
        return nil;
    gDiagPath = [dir stringByAppendingPathComponent:@"trollvnc-diagnostic.txt"];
    return gDiagPath;
}

#pragma mark - 写日志

static void diagAppend(NSString *text) {
    NSString *path = tvDiagFile();
    if (!path)
        return;
    if (!gDiagLock)
        gDiagLock = [NSLock new];
    [gDiagLock lock];
    NSFileManager *fm = [NSFileManager defaultManager];
    if (![fm fileExistsAtPath:path]) {
        [fm createFileAtPath:path contents:nil attributes:nil];
    }
    NSFileHandle *fh = [NSFileHandle fileHandleForWritingAtPath:path];
    if (fh) {
        @try {
            [fh seekToEndOfFile];
            [fh writeData:[text dataUsingEncoding:NSUTF8StringEncoding]];
        } @catch (NSException *e) {
            // 诊断自己绝不能把进程搞崩
        }
        @try { [fh closeFile]; } @catch (NSException *e) {}
    }
    [gDiagLock unlock];
}

void tvDiagLog(NSString *format, ...) {
    va_list args;
    va_start(args, format);
    NSString *message = [[NSString alloc] initWithFormat:format arguments:args];
    va_end(args);

    NSDateFormatter *df = [NSDateFormatter new];
    df.dateFormat = @"yyyy-MM-dd HH:mm:ss";
    NSString *line = [NSString stringWithFormat:@"[%@] %@\n", [df stringFromDate:[NSDate date]], message];
    NSLog(@"[Mirror17Diag] %@", message);
    diagAppend(line);
}

#pragma mark - 崩溃日志副本

/// 把最近的崩溃日志（含 trollvnc / SpringBoard / mirror17 的）复制到诊断目录，
/// 用户一次就能把「环境 + 错误 + 崩溃」全发过来。
static NSArray<NSString *> *diagCopyCrashes(void) {
    NSFileManager *fm = [NSFileManager defaultManager];
    NSMutableArray *copied = [NSMutableArray array];
    NSArray *roots = @[@"/var/mobile/Library/Logs/CrashReporter",
                       @"/var/mobile/Library/Logs/DiagnosticReports",
                       @"/var/jb/var/mobile/Library/Logs/CrashReporter"];
    NSDate *cutoff = [NSDate dateWithTimeIntervalSinceNow:-7 * 24 * 3600];
    for (NSString *root in roots) {
        NSArray *names = [fm contentsOfDirectoryAtPath:root error:NULL];
        if (!names)
            continue;
        for (NSString *name in names) {
            NSString *lower = name.lowercaseString;
            BOOL relevant = [lower containsString:@"trollvnc"] || [lower containsString:@"mirror17"] ||
                            [lower containsString:@"springboard"] || [lower containsString:@"preferences"];
            if (!relevant)
                continue;
            NSString *src = [root stringByAppendingPathComponent:name];
            NSDictionary *attrs = [fm attributesOfItemAtPath:src error:NULL];
            if (attrs && [attrs[NSFileModificationDate] compare:cutoff] == NSOrderedAscending)
                continue;
            NSString *dst = [[tvDiagDirectory() stringByAppendingPathComponent:@"崩溃日志"]
                             stringByAppendingPathComponent:name];
            [fm createDirectoryAtPath:[dst stringByDeletingLastPathComponent]
          withIntermediateDirectories:YES attributes:nil error:NULL];
            if ([fm copyItemAtPath:src toPath:dst error:NULL])
                [copied addObject:name];
        }
    }
    return copied;
}

#pragma mark - 启动记录

void tvDiagStart(NSString *tag) {
    NSMutableString *out = [NSMutableString string];
    NSDateFormatter *df = [NSDateFormatter new];
    df.dateFormat = @"yyyy-MM-dd HH:mm:ss";
    [out appendFormat:@"==== TrollVNC（王源构建版）诊断 ====\n"];
    [out appendFormat:@"时间：%@\n", [df stringFromDate:[NSDate date]]];
    [out appendFormat:@"事件：%@\n\n", tag];

    [out appendFormat:@"—— 环境 ——\n"];
    [out appendFormat:@"服务端版本：%s（%s）\n", PACKAGE_VERSION, THEOS_PACKAGE_SCHEME];
    [out appendFormat:@"iOS：%@\n", diagSysctl("kern.osproductversion") ?: @"未知"];
    [out appendFormat:@"内建：%@\n", diagSysctl("kern.osversion") ?: @"未知"];
    [out appendFormat:@"机型：%@\n", diagSysctl("hw.machine") ?: @"未知"];
    [out appendFormat:@"cpu：%@\n", diagSysctl("hw.ncpu") ?: @"?"];
    [out appendFormat:@"uid=%d（0 才是 root）\n", getuid()];

    [out appendFormat:@"\n—— 越狱环境 ——\n"];
    [out appendFormat:@"/var/jb：%@\n", diagFileExists(@"/var/jb")];
    [out appendFormat:@"ellekit（/var/jb/usr/lib/libellekit.dylib）：%@\n",
                      diagFileExists(@"/var/jb/usr/lib/libellekit.dylib")];
    [out appendFormat:@"substrate（/var/jb/usr/lib/libsubstrate.dylib）：%@\n",
                      diagFileExists(@"/var/jb/usr/lib/libsubstrate.dylib")];
    [out appendFormat:@"PreferenceLoader：%@\n",
                      diagFileExists(@"/var/jb/Library/PreferenceLoader/PreferenceLoader.dylib")];
    [out appendFormat:@"TrollVNC 设置面板：%@\n",
                      diagFileExists(@"/var/jb/Library/PreferenceBundles/TrollVNCPrefs.bundle")];
    [out appendFormat:@"TrollVNC 守护进程 plist：%@\n",
                      diagFileExists(@"/var/jb/Library/LaunchDaemons/com.82flex.trollvnc.plist")];

    [out appendFormat:@"\n—— 关键私有接口 ——\n"];
    [out appendFormat:@"CARenderServerRenderDisplay：%@\n",
                      diagSymbol(@"/System/Library/PrivateFrameworks/QuartzCore.framework/QuartzCore",
                                 "CARenderServerRenderDisplay")];
    [out appendFormat:@"VBApplicationDisplayServices：%@\n",
                      diagSymbol(@"/System/Library/PrivateFrameworks/UIKitCore.framework/UIKitCore",
                                 "VBApplicationDisplayServices")];
    [out appendFormat:@"VideoToolbox：%@\n",
                      diagSymbol(@"/System/Library/Frameworks/VideoToolbox.framework/VideoToolbox",
                                 "VTCompressionSessionCreate")];
    [out appendFormat:@"IOHIDEvent 注入：%@\n",
                      diagSymbol(@"/System/Library/PrivateFrameworks/IOKit.framework/IOKit",
                                 "IOHIDEventSystemClientDispatchEvent")];
    [out appendFormat:@"BKSDisplayBrightnessSet：%@\n",
                      diagSymbol(@"/System/Library/PrivateFrameworks/BackBoardServices.framework/BackBoardServices",
                                 "BKSDisplayBrightnessSet")];

    [out appendFormat:@"\n—— 目录 ——\n"];
    [out appendFormat:@"诊断文件：%@\n", tvDiagFile() ?: @"⚠️ 没有可写目录"];
    [out appendFormat:@"\n（下面开始是这个进程的日志；把整份文件发给作者即可）\n"];
    [out appendString:@"----------------------------------------------------------\n"];

    // 环境头每次覆盖重写，日志部分接着往下追加
    NSString *path = tvDiagFile();
    if (path) {
        if (!gDiagLock)
            gDiagLock = [NSLock new];
        [gDiagLock lock];
        [out writeToFile:path atomically:YES encoding:NSUTF8StringEncoding error:NULL];
        [gDiagLock unlock];
    }

    NSArray<NSString *> *crashes = diagCopyCrashes();
    tvDiagLog(@"启动记录写入完成%@", crashes.count
              ? [NSString stringWithFormat:@"；已复制 %lu 份崩溃日志：%@", (unsigned long)crashes.count,
                                           [crashes componentsJoinedByString:@", "]]
              : @"；没有找到相关崩溃日志");
}
