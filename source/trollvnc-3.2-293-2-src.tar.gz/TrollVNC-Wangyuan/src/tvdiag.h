#import <Foundation/Foundation.h>

/// 手机端诊断（王源构建版加的功能，上游没有）。
///
/// 目的：作者手上没有 iOS 15 / 16 的设备，靠用户回传的环境 + 错误日志来定位兼容性问题。
///
/// 诊断文件写在「文件」App 能看到的地方：
///     /var/mobile/Documents/Mirror17/trollvnc-diagnostic.txt
/// 写不进去就退回 /var/jb/var/mobile/Documents/… 再退回 /tmp/Mirror17/，并在文件里说明。
///
/// 用法：
///   tvDiagStart(@"trollvncserver 启动");   // 进程启动时调一次：写环境头 + 拷贝最近崩溃日志
///   tvDiagLog(@"native listen 失败：%s", strerror(errno));   // 关键时刻追加一行
NSString *tvDiagDirectory(void);
void tvDiagStart(NSString *tag);
void tvDiagLog(NSString *format, ...) NS_FORMAT_FUNCTION(1, 2);
/// 诊断文件路径（可能为 nil，调用方自己判空）
NSString *tvDiagFile(void);
